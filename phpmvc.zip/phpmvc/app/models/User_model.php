<?php
class User_model {
	private $nama = "Serlina";

	public function getUser(){
		return $this->nama;
	}
}
?>